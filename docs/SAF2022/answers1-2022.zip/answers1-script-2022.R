################### Exercise sheet 1 ###################

# In this answer sheet, we assume that the density independent model has been run, and that its output is stored in the 'sim' object.
# We further assume that the results of the density depend case are stored in the 'sim_dens' object.

### Construct the matrix

L = matrix(0, nrow = 6, ncol = 6) # This will be our Leslie matrix, for now it is filled with zeroes.
p0=0.8 # Establishment probability
fec= c(0.57, 2.10, 4.25, 4.25, 4.25, 4.25) # Fecundities
surv=c(0.52, 0.60, 0.71, 0.71, 0.71) # Survival probabilities

for(i in 1:ncol(L)) # For each column,
{
  L[1,i] = fec[i]*p0 # Add the effective fecundity to the first row
  if(i < ncol(L))
  {
    L[i+1,i] = surv[i] # And survival to the corresponding row
  }
}

### Eigen analysis

lambda = eigen(L)$values[1] 
age_distr = eigen(L)$vectors[,1]/sum( eigen(L)$vectors[,1] )

### Iterate the matrix

v=c(1000,0,0,0,0,0) # Initial population vector
ps=c(1000) # vector with initial pop. size
for(i in 1:10) # For 10 years,
{
  v = L %*% v # Iterate the matrix
  ps = c(ps, sum(v)) # Compute the size of the population
}

### Plot the results

par(mfrow=c(1,1))
plot(ps, ylim=c(0, 10^5), xlab = "Time (in years)", ylab = "Wild boar population size", main = "Wild boar population size as a function of time", pch=16, cex=2)

### Compute R0

Fec=c(0.57, 2.1, 4.25, 4.25, 4.25, 4.25)
P0=0.8
Psurv=c(0.52,0.60,0.71,0.71,0.71)


Csurv=c(P0) #  Survival to age 'a' vector
for(i in 1:5)
{
  Csurv = c( Csurv, tail(Csurv,1)*Psurv[i] )
}
R0 = sum( Csurv*Fec ) # Compute R0

### Plot simulated population size and Leslie matrix predictions on the same graph.

sps=c(1000) # vector initial simulated pop. size
for(i in 1:10) # For 10 years,
{
  sps = c( sps, sum( sim[i+1,] ) )  # Compute the size of the population
}

par(mfrow=c(1,1))
plot(ps, ylim=c(0, 10^5), xlab = "Time (in years)", ylab = "Wild boar population size", main = "Wild boar population size as a function of time", pch=16, cex=2)
points(sps, pch=16, cex=1.5, col="red" )
legend("topleft", legend=c("Matrix iteration", "Individual-based simulation"), pch=c(16,16), col=c("black", "red"))

### Same task with age distributions.

sim_age = tail(sim,1) / sum( tail(sim,1) ) # Compute the final age distribution in the simulations.

# Plot the results.
plot( as.numeric( age_distr), ylim=c(0,1), xlab = "Age-class", ylab = "Age-class frequency", main = "Wild boar population age-structure", pch=16, cex=2)
points(as.numeric( sim_age ), pch=16, cex=1.5, col="red" )
legend("topleft", legend=c("Eigen analysis", "Individual-based simulation"), pch=c(16,16), col=c("black", "red"))

### Population size variation over time in the density-dependent case.

psd = c() # Calculate population sizes at each time step
for(i in 1:nrow(sim_dens))
{
  psd=c( psd, sum(sim_dens[i,]) )
}
par(mfrow=c(1,1))

# Plot the result
plot(psd, ylim=c(0, max(psd)*1.1), xlab = "Time (in years)", ylab = "Simulated wild boar population size", main = "Simulated wild boar population size as a function of time", pch=16, cex=1.5, col="red")

### Iterate the density-dependent Leslie matrix and compute R0

pld=c(1000) # Initial population size
vd=c(1000,0,0,0,0,0) # Initial population vector
gamma = 0.0005

# Calculate R0 at initial time. Same approach as before but P0 now depends on population size.
Fec=c(0.57, 2.1, 4.25, 4.25, 4.25, 4.25)
Psurv=c(0.52,0.60,0.71,0.71,0.71)
P0=0.8/(1 + gamma*pld[1])

Csurv=c(1)
for(i in 1:5)
{
  Csurv = c( Csurv, tail(Csurv,1)*Psurv[i] )
}

r0=c( P0*sum( Csurv*Fec ) )

# Iterate matrix and compute R0 for 100 years
for(t in 1:100)
{
  Ld=L # Reinitialise matrix to the density independent case
  for(i in 1:ncol(Ld))
  {
    Ld[1,i] = L[1,i]/(1 + gamma*pld[t]) # Update the effective fecundities to incorporate density dependence. 
  }
  vd = Ld %*% vd # Iterate the matrix once
  pld=c(pld, sum(vd)) # Store population size

  # Compute R0
  P0=0.8/( 1 + gamma*tail(pld,1) )
  r0=c( r0, P0*sum( Csurv*Fec ) )
  
}

# Plot the results for population size
par(mfrow=c(1,1))
plot(pld, ylim=c(0, max(pld, psd)*1.1), xlab = "Time (in years)", ylab = "Density-dependent wild boar population size", main = "Density-dependent wild boar population size as a function of time", type="l", lwd=7)
points(psd, pch=16, cex=1.5, col="red" )
legend("topleft", legend=c("Matrix iteration", "Individual-based simulation"), pch=c(16,16), col=c("black", "red"))

# Plot R0 as a function of time
par(mfrow=c(1,1))
plot(r0, ylim=c(0, max(r0)*1.1), xlab = "Time (in years)", ylab = "R0", main = "R0 as a function of time", pch=16, cex=1.7)
lines(x=c(-10, length(r0)+10), y=c(1,1), lty=2, lwd=5, col="red" )
